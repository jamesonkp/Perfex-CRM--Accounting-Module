<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Migration_Version_127 extends App_module_migration
{
    public function up()
    {        
        add_option('acc_invoice_discount_payment_account', 1);
        add_option('acc_invoice_discount_deposit_to', 19);
    }
}
